module Lib
    ( someFunc
    ) where

import Data.Array.Accelerate as A
import Data.Array.Accelerate as CPU


someFunc :: IO ()
someFunc = print 2
