# Changelog for parallelCompilers

## Unreleased changes
